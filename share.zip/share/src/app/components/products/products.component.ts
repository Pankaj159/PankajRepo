import { Component, OnInit } from '@angular/core';  
import { IProduct } from 'src/app/model/products.model';
import { Product_Data } from 'src/app/model/productDetails';
import { CartServiceService } from 'src/app/services/cart-service.service';
import { Router } from '@angular/router';
import { Subscription,Observable } from 'rxjs';



@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products:IProduct[]=[];

  message:string[]=[];
  price:number=0;
  price1:number=1000000;
  category:string="";
  search:string="";
  
  name:string=localStorage.getItem("name");

//parameter for updating
id:number;
pname:string;
description:string;
rating:number;
pcategory:string;
cost:number;
updateProduct(product){
  product.productName=this.pname,
  product.description=this.description,
  product.productRating=this.rating,
  product.productCategory=this.category,
  product.cost=this.cost
}
  constructor(private cartservice:CartServiceService,private router:Router) {}

  ngOnInit() {
    this.products=Product_Data;
    this.data$.subscribe(msg=>this.message.push(msg))
     //this.getProducts();
  }
  getProducts(){
    this.cartservice.getProducts().subscribe((response:IProduct[])=>{
    this.products=response;})
  }

  addtoCart(product){
    alert("Product has been added to Cart");
    this.cartservice.addToCart(product)
  }

  toCart(){
    this.router.navigate(['./cart'])
  }

  data$=Observable.create(observer =>{
    setTimeout(() => {
      observer.next(`Hello ${this.name}`)
    }, 1000)
    setTimeout(() => {
      observer.next("Let's do Shopping!")
    }, 2000);
    setTimeout(() => {
      observer.next("We provide best quality product")
    }, 3000);
    setTimeout(() => {
      observer.complete();
    }, 4000);
  })

  addProduct(product){
    this.products.push({
      productId:product.value.id,
    productName:product.value.name,
    description:product.value.description,
    productRating:product.value.rating,
    productCategory:product.value.category,
    cost:product.value.cost,
    image:product.value.image
    })
    alert('Product has been added')
  }

}
