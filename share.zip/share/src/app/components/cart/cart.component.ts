import { Component, OnInit } from '@angular/core';
import { CartServiceService } from 'src/app/services/cart-service.service';
import { IProduct } from 'src/app/model/products.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  carts:IProduct[];
  price:number=0;

  items:number=0;
  constructor(private cartService:CartServiceService,private router:Router) { }

  
  ngOnInit() {
    this.carts=this.cartService.getCart();
    this.price=this.cartService.getTotalPrice();
    this.items=this.cartService.getItems();
  }

  logout(){
    this.router.navigate(['/login'])
  }

  toProducts(){
    this.router.navigate(['/products'])
  }

  deleteItem(product){
    this.cartService.deleteItem(product);
    this.price=this.cartService.getTotalPrice();
    this.items=this.cartService.getItems();
  }
}
