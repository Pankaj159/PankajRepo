import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { validateConfig } from '@angular/router/src/config';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  username=new FormControl('',[Validators.required]);
  name=new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]{2,20}')]);
  email=new FormControl('',[Validators.required,Validators.email]);
  phoneNumber=new FormControl('',[Validators.required]);
  dob=new FormControl('',[Validators.required]);
  password=new FormControl('',[Validators.required,Validators.minLength(8)]);
  cnfpassword=new FormControl('',[Validators.required,this.confirmPassword])
  registerForm: FormGroup;

  constructor(private formbuilder:FormBuilder,private router:Router) {
    this.registerForm=formbuilder.group({
      username:this.username,
      name:this.name,
      email:this.email,
      phoneNumber:this.phoneNumber,
      dob:this.dob,
      password:this.password,
      cnfpassword:this.cnfpassword
    }) 
   }
   backToLogin(){
     localStorage.setItem("username",this.registerForm.value.username)
     localStorage.setItem("password",this.registerForm.value.password)
     localStorage.setItem("name",this.registerForm.value.name)
     localStorage.setItem("email",this.registerForm.value.email)
    this.router.navigate(['/login'])
   }

   confirmPassword(input : FormControl){
    if(input.root){
      const samePassword = input.root.value.password === input.value;
      return samePassword ? null : {cnfpassword : true};
    }
}

  ngOnInit() { 
  }

}
