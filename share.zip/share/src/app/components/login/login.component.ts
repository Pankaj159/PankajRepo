import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms'
import {Router} from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
userName1:string=localStorage.getItem("username");
userName2:string=localStorage.getItem("email");
passWord1:string=localStorage.getItem("password");
message:string;
  
  constructor(public router:Router) { }

  ngOnInit() {
  }

  onRegister(){
    this.router.navigate(['/register'])
  }
  onClick(f :NgForm){
    if((this.userName1 === f.value.username||this.userName2 === f.value.username) && this.passWord1===f.value.password){
      this.router.navigate(['/products'])
    }
    else {
    this.message="UserName and Password Invalid"}
  }
}
