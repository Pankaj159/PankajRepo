import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'
import {RouterModule} from '@angular/router'
import { HttpClientModule } from '@angular/common/http'
import {InMemoryWebApiModule} from 'angular-in-memory-web-api'

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { App_Routes } from './app.routes';
import { RoutesComponent } from './components/routes/routes.component';
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import { DataService } from './services/data.service';
import { OrderByPipe } from './pipes/order-by.pipe';
import { SearchPipe } from './pipes/search.pipe';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    RoutesComponent,
    ProductsComponent,
    CartComponent,
    OrderByPipe,
    SearchPipe
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,RouterModule.forRoot(App_Routes),HttpClientModule,
    InMemoryWebApiModule.forRoot(DataService)
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
