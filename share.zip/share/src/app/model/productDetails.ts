import { IProduct } from './products.model';

export const Product_Data:IProduct[]=[{
    productId:1,
    productName:"SamsungM30s",
    description:"Blue, 6GB RAM, 256GB Storage",
    productRating:4.5,
    productCategory:"Electronic",
    cost:19999,
    image:"./assets/images/SamsungM30s.jpg"
},
{
    productId:2,
    productName:"RealMe 5 Pro",
    description:"Blue, 4GB RAM, 64GB Storage",
    productRating:4.2,
    productCategory:"Electronic",
    cost:9999,
    image:"./assets/images/realme5pro.jpg"
},
{
    productId:3,
    productName:"One Plus 7t",
    description:"Glacier Blue, 8GB RAM, Fluid AMOLED Display",
    productRating:4.8,
    productCategory:"Electronic",
    cost:29999,
    image:"./assets/images/oneplus7t.jpg"
},
{
    productId:4,
    productName:"I Phone 11 Pro",
    description:"Midnight Green · 512GB",
    productRating:4.9,
    productCategory:"Electronic",
    cost:101400,
    image:"./assets/images/iphone11pro.jpg"
},
{
    productId:5,
    productName:"Identity",
    description:"Midnight Green Shirt and Pant",
    productRating:4.9,
    productCategory:"Clothes",
    cost:2000,
    image:"./assets/images/cloth1.png"
},
{
    productId:6,
    productName:"Flying Machine",
    description:"Brown Checked Half Sleeve",
    productRating:4.9,
    productCategory:"Clothes",
    cost:999,
    image:"./assets/images/cloth2.png"
},
{
    productId:7,
    productName:"Here and Now",
    description:"Gym Wear, Night Wear",
    productRating:4.9,
    productCategory:"Clothes",
    cost:2999,
    image:"./assets/images/cloth3.png"
},
{
    productId:8,
    productName:"Louis Phillipe",
    description:"Red Coat and Pant",
    productRating:4.9,
    productCategory:"Clothes",
    cost:5999,
    image:"./assets/images/cloth4.jfif"
}]