export interface ICart{
    name:string;
    price:number;
}