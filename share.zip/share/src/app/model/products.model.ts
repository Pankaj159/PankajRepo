export interface IProduct{
    productId:number;
    productName:string;
    description:string;
    productRating:number;
    productCategory:string;
    cost:number;
    image:string;
}