export interface IUser{
    firstname:string,
    lastname:string,
    email:string,
    phoneNumber:number,
    dob:Date,
    password:string, 
    cnfpassword:string
}
