import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api'

@Injectable()
export class DataService implements InMemoryDbService{

    createDb(){
      let products=[
    {
        productId:1,
        productName:"SamsungM30s",
        description:"Blue, 6GB RAM, 256GB Storage",
        productRating:4.5,
        productCategory:"Electronic",
        cost:20000,
        image:"./assets/images/SamsungM30s.jpg"
    },
    {
        productId:2,
        productName:"RealMe 5 Pro",
        description:"Blue, 4GB RAM, 64GB Storage",
        productRating:4.2,
        productCategory:"Electronic",
        cost:13999,
        image:"./assets/images/realme5pro.jpg"
    },
    {
        productId:3,
        productName:"One Plus 7t",
        description:"Glacier Blue, 8GB RAM, Fluid AMOLED Display",
        productRating:4.8,
        productCategory:"Electronic",
        cost:20000,
        image:"./assets/images/oneplus7t.jpg"
    },
    {
        productId:4,
        productName:"I Phone 11 Pro",
        description:"Midnight Green · 512GB",
        productRating:4.9,
        productCategory:"Electronic",
        cost:101400,
        image:"./assets/images/iphone11pro.jpg"
    }]
    return { products };
    }
  }