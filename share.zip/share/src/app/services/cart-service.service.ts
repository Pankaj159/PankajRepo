import { Injectable } from '@angular/core';
import { IProduct } from '../model/products.model';
import { HttpClient } from '@angular/common/http'
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService{

  totalPrice:number=0;
  items:number=0;

  server_url:string="http://localhost:4200/api/products";

  cart:IProduct[]=[];

  constructor(private dataService:DataService, private httpClient:HttpClient) {}

getProducts(){
return this.httpClient.get(this.server_url)
}

  addToCart(product){
    this.cart.push(product);
    this.totalPrice=this.totalPrice + product.cost;
    this.items=this.items+1;
  }

  getCart(){
    return this.cart;
  }

  deleteItem(product:IProduct){

    this.totalPrice=this.totalPrice-product.cost;
    this.items=this.items-1;
    const index:number=this.cart.indexOf(product)
    if(index!=-1){
      this.cart.splice(index,1);
    }
   
  }

  getTotalPrice(){
    return this.totalPrice;
  }

  getItems(){
    return this.items;
  }
}