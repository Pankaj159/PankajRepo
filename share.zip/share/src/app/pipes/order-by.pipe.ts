import { Pipe, PipeTransform } from '@angular/core';
import { IProduct } from '../model/products.model';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(products: IProduct[],price:number,price1:number,category:string): any {

    if(products.length === 0 || price === null || category==="" ){
      return products;
    }
    // if(!search){
    //      return products;
    //    }
  

    let result:IProduct[]=[];
    //search=search.toLowerCase()
    // for(let product of products){
    //   if(product.cost>price){
    //     result.push(product);
    //   }
    // }
    for(let product of products){
      if(product.productCategory===category){
      if(product.cost<price1){
        if(product.cost>price){
           result.push(product);
        }
      }
      }
    // if(product['productName'].toLowerCase().includes(search)){
    //   result.push(product)
    // }
  }
    return result;
  }
}
